
package modelo;

import service.CSVSerializable;

public class Animal implements Comparable<Animal>, CSVSerializable {
    private int id;
    private String nombre;
    private String especie;
    private TipoAlimentacion alimentacion;

    public Animal(int id, String nombre, String especie, TipoAlimentacion alimentacion) {
        this.id = id;
        this.nombre = nombre;
        this.especie = especie;
        this.alimentacion = alimentacion;
    }
    
    
    @Override
    public int compareTo(Animal other) {
        
        return Integer.compare(id, other.id); 
    }
    
    @Override
    public String toCSV() {

        return id + "," + nombre + "," + especie + "," + alimentacion;
        
    }

    @Override
    public String toString() {
        
        return "Animal{" + "id=" + id + ", nombre=" + nombre + ", especie=" + especie + ", alimentacion=" + alimentacion + '}';
        
    }
    
    public static Animal fromCSV(String csv) {
        String[] partes = csv.split(","); 

        if (partes.length != 4) {
            throw new IllegalArgumentException("Formato CSV incorrecto. Se esperaban 4 elementos.");
        }

        int id = Integer.parseInt(partes[0]);
        String nombre = partes[1];
        String especie = partes[2];
        TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(partes[3].toUpperCase());

        return new Animal(id, nombre, especie, alimentacion);
    }

    public String getNombre() {
        return nombre;
    }

    public TipoAlimentacion getAlimentacion() {
        return alimentacion;
    }
    
    
    
    
}
