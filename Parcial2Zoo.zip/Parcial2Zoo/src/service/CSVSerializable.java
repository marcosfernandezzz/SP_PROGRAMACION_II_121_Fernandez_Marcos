
package service;

import modelo.Animal;

@FunctionalInterface
public interface CSVSerializable {
    
    public String toCSV();
    
    static CSVSerializable fromCSV(String csv) {
        throw new UnsupportedOperationException("Método fromCSV no implementado");
    }
}
