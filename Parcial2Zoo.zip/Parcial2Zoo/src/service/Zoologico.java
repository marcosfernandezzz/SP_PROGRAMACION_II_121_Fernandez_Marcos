
package service;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import modelo.Animal;
import modelo.TipoAlimentacion;

public class Zoologico<T extends Comparable<T> & CSVSerializable> implements CSVSerializable {
    
    private List<T> inventario = new ArrayList<>();



    
    public void agregar(T elemento) {
        if(elemento == null){
            throw new NullPointerException("Elemento nulo");
        }
        
        inventario.add(elemento);
    }

    
    public T obtener(int indice) {
        chequearRangoIndice(indice);
        
        return inventario.get(indice);
    }

    
    public void eliminar(int indice) {
        chequearRangoIndice(indice);
        
        inventario.remove(indice);
    }

    
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> filtrado = new ArrayList<>();
        for (T elemento : inventario) {
            if (criterio.test(elemento)) {
                filtrado.add(elemento);
            }
        }
        return filtrado;
    }

   
    public void ordenarNatural() {
        if (!inventario.isEmpty() && inventario.get(0) instanceof Comparable) {
            
            
            Comparator<T> comparator = (a, b) -> ((Comparable<T>) a).compareTo(b);  // Usamos compareTo del Comparable
            
            inventario.sort(comparator);
            
        } else {
            
            throw new UnsupportedOperationException("El tipo T no es Comparable, no se puede ordenar de manera natural.");         
        }
    }

    
    public void ordenar(Comparator<T> comparator) {
        inventario.sort(comparator);
    }

    
    public List<T> obtenerTodos() {
        return new ArrayList<>(inventario);
    }

    
    public int tamano() {
        return inventario.size();
    }

    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Inventario Zoologico:\n");
        for (T elemento : inventario) {
            sb.append(elemento.toString()).append("\n");
        }
        return sb.toString();
    }
    
    private void chequearRangoIndice(int indice){
        if(indice < 0 || indice >= inventario.size()){
            throw new IndexOutOfBoundsException("Indice fuera de rango");
        }
    }

    @Override
    public String toCSV() {
        String csvDatos = "";
        for (T elemento : inventario) {
            csvDatos += elemento.toCSV() + "\n";  
        }
        return csvDatos;
    }
    
    
     public List<T> filtrarPorAlimentacion(TipoAlimentacion tipo) {
        List<T> filtrado = new ArrayList<>();
        for (T elemento : inventario) {
            if (elemento instanceof Animal) {
                Animal animal = (Animal) elemento;
                if (animal.getAlimentacion() == tipo) {
                    filtrado.add((T) animal);
                }
            }
        }
        return filtrado;
    }
     
     public List<T> filtrarPorNombre(String palabra) {
        List<T> filtrado = new ArrayList<>();
        for (T elemento : inventario) {
            if (elemento instanceof Animal) {
                Animal animal = (Animal) elemento;
                if (animal.getNombre().toLowerCase().contains(palabra.toLowerCase())) {
                    filtrado.add((T) animal);
                }
            }
        }
        return filtrado;
    }
     
    public void paraCadaElemento(Consumer<T> accion) {
    Iterator<T> iterator = inventario.iterator();  
    
    while (iterator.hasNext()) {
        T elemento = iterator.next(); 
        accion.accept(elemento);  
    }
    
}
    
    public static List<Animal> cargarDesdeArchivo(String path) {
    List<Animal> toReturn = new ArrayList<>();
    
    try (BufferedReader br = new BufferedReader(new FileReader(path))) {
        String linea;
        
        
        while ((linea = br.readLine()) != null) {
            linea = linea.trim();
            
            
            
            String[] data = linea.split(",");
            

            if (data.length == 4) {
                

                int id = Integer.parseInt(data[0]); 
                String nombre = data[1]; 
                String especie = data[2]; 
                    
                TipoAlimentacion alimentacion = TipoAlimentacion.valueOf(data[3].trim().toUpperCase());
                    
                Animal a = new Animal(id, nombre, especie, alimentacion);
                toReturn.add(a);
                
            } else {
                System.out.println("Línea con formato incorrecto: " + linea);
            }
        }
    } catch (IOException ex) {
        System.out.println("Error de lectura: " + ex.getMessage());
    }

    return toReturn;
    }
    
    
    
    public void guardarEnCSV(String path) {
    File archivo = new File(path);

    try {
        if (archivo.exists()) {
            System.out.println("El archivo ya existe");
        } else {
            archivo.createNewFile();
            System.out.println("Se ha creado el archivo");
        }

    } catch (IOException ex) {
        System.out.println("Ocurrió un error al intentar crear el archivo");
    }

    try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
        bw.write("id,nombre,especie,alimentacion\n");

        for (T animal : inventario) {
            bw.write(animal.toCSV() + "\n");
        }

    } catch (IOException ex) {
        System.out.println("Ocurrió un error al escribir en el archivo CSV: " + ex.getMessage());
    }
}
    
    public void cargarDesdeCSV(String path, Function<String, T> fromCSV) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String linea;
            
            while ((linea = br.readLine()) != null) {
                linea = linea.trim(); 
                
                
                T elemento = fromCSV.apply(linea);
                
                if (elemento != null) {
                    inventario.add(elemento);  
                }
            }
        } catch (IOException e) {
            System.err.println("Error al leer el archivo CSV: " + e.getMessage());
            throw e;
        }
    }
    
    public void guardarEnArchivo(String path) throws IOException {
        File archivo = new File(path);
        archivo.getParentFile().mkdirs();  
        
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(path))) {
            oos.writeObject(inventario);
            System.out.println("Inventario guardado correctamente en el archivo: " + path);
        } catch (IOException e) {
            System.err.println("Error al guardar el archivo binario: " + e.getMessage());
            throw e; 
        }
    }

    
    public void imprimirInventario() {
        for (T elemento : inventario) {
            System.out.println(elemento);
        }
    }
        
    
}
    
    

    
    



    
    

   

    
